# Handling categorical data

```{tableofcontents}
```
