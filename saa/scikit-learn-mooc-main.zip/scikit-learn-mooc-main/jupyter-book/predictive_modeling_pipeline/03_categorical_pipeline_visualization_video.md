# 🎥 Visualizing scikit-learn pipelines in Jupyter

<iframe class="video" width="640px" height="480px"
        src="https://www.youtube.com/embed/D0Nyumrs0G4?rel=0"
        allowfullscreen></iframe>
