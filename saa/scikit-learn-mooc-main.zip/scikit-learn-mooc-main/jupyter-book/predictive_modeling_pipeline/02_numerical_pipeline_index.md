# Fitting a scikit-learn model on numerical data

```{tableofcontents}
```
