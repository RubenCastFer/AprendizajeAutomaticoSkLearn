# ✅ Quiz M6.03

```{admonition} Question
When compared to random forests, gradient boosting is usually trained using:

- a) shallower trees
- b) deeper trees
- c) a subset of features
- d) all features

_Select all answers that apply_
```

+++

```{admonition} Question
Which of the hyperparameter(s) do not exist in random forest but exists in gradient boosting:

- a) number of estimators
- b) maximum depth
- c) learning rate

_Select all answers that apply_
```

+++

```{admonition} Question
Which of the following options are correct about the benefits of ensemble models?

- a) Better generalization performance
- b) Reduced sensitivity to hyperparameter tuning of individual predictors
- c) Better interpretability

_Select all answers that apply_
```
