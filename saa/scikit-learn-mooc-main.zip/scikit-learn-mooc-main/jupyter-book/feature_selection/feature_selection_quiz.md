# ✅ Quiz

```{admonition} Question
What is the main advantage of using feature selection?

- a) speeding-up the training of an algorithm
- b) fine tuning the model's performance
- c) remove noisy features

_Select a single answer_
```

+++

```{admonition} Question
When selecting feature, the decision should be made using:

- a) the entire dataset
- b) the training set
- c) the testing set

_Select a single answer_
```
