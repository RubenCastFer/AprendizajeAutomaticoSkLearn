# ✅ Quiz M2.03

```{admonition} Question
Fitting a model with a high bias:

- a) causes an underfitted model?
- b) causes an overfitted model?
- c) increases the sensitivity of the learned prediction function to a random resampling of the training set observations?
- d) causes the learned prediction function to make systematic errors?

_Select all answers that apply_
```

+++

```{admonition} Question
Fitting a high variance model:

- a) causes an underfitted model?
- b) causes an overfitted model?
- c) increases the sensitivity of the learned prediction function to a random resampling of the training set observations?
- d) causes the learned prediction function to make systematic errors?

_Select all answers that apply_
```
