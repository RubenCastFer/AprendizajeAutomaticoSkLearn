# ✅ Quiz M2.01

```{admonition} Question
A model that is underfitting:

- a) is too complex and thus highly flexible
- b) is too constrained and thus limited by its expressivity
- c) often makes prediction errors, even on training samples
- d) focuses too much on noisy details of the training set

_Select all answers that apply_
```

+++

```{admonition} Question
A model that is overfitting:

- a) is too complex and thus highly flexible
- b) is too constrained and thus limited by its expressivity
- c) often makes prediction errors, even on training samples
- d) focuses too much on noisy details of the training set

_Select all answers that apply_
```
