# ✅ Quiz M5.04

```{admonition} Question
If a decision tree is overfitting, you need to increase the maximum depth.

- a) True
- b) False

_Select a single answer_
```

+++

```{admonition} Question
How should you choose the maximum depth of a decision tree?

- a) choosing the depth maximizing the score on a validation set with a
  cross-validation, with a grid-search for instance
- b) choosing the depth maximizing the score on the train set
- c) choosing the depth maximizing the score on the test set

_Select all answers that apply_
```
