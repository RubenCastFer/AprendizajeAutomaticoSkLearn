# Intuitions on tree-based models

```{tableofcontents}

```
