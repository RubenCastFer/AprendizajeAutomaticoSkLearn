# ✅ Quiz M7.01

```{admonition} Question
What the benefit of using cross-validation?

- a) Give information about performance variability
- b) Remove the need to use a baseline algorithm
- c) Give information regarding under- or over-fitting of a model

_Select all answers that apply_
```

+++

```{admonition} Question
Does a dummy classifier or regressor rely on the input feature values in
the input data `X` to make the predictions?

- a) Yes
- b) No

_Select a single answer_
```

+++

```{admonition} Question
Does a dummy classifier from scikit-learn always make constant predictions
whatever the chosen strategy?

- a) Yes
- b) No

_Select a single answer_
```
