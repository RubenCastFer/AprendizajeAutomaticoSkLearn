# Comparing a model with simple baselines

```{tableofcontents}

```
