# Choice of cross-validation

```{tableofcontents}

```
