# Acknowledgement

## Figure attributions

The diagram presenting the API design in the module "The predictive modeling
pipeline" used the following figures:

- The "Parameters Free Icon" is licensed under CC-BY 3.0 -
  [source](https://www.onlinewebfonts.com/icon/512285)
- The "Settings Gears SVG Vector" is licensed under CC0 -
  [source](https://www.svgrepo.com/svg/57066/settings-gears)
- The "Close icon" is licensed under MIT -
  [source](https://www.iconfinder.com/icons/211652/close_icon)
