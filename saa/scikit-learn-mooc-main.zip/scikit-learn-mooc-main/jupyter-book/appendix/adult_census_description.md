# The adult census dataset

This dataset is a collection of information related to a person. The prediction
task is to predict whether a person is earning a salary above or below 50 k$.

We extensively exploring this dataset in the first module "The predictive
modeling pipeline", in the first sequence "Tabular data exploration", in the
first notebook "First look at our dataset".

To avoid repeating the same information, we redirect the reader to this
particular notebook.
