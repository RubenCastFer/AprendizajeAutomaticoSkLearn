# Linear model for classification

```{tableofcontents}

```
