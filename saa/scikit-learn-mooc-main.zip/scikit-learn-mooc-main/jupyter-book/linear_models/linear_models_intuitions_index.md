# Intuitions on linear models

```{tableofcontents}

```
