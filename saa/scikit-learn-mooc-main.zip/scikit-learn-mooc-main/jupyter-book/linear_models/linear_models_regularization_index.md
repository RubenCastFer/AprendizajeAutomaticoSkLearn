# Regularization in linear model

```{tableofcontents}

```
