This directory contains didactic figures and scripts that generate them.
