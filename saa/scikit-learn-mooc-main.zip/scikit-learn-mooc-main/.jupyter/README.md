This directory is to setup jupyter on binder

