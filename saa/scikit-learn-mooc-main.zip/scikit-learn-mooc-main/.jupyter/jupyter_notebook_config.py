# To use jupytext in binder
c.ContentsManager.preferred_jupytext_formats_read = 'py:percent'  # noqa
